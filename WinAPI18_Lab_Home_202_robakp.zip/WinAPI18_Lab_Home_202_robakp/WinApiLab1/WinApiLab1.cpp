// WinApiLab1.cpp : Defines the entry point for the application.
//

#include "framework.h"
#include "WinApiLab1.h"
using namespace std;
#define MAX_LOADSTRING 100
#define ANISPEED 25
#define ANIMATING 2

#pragma comment(lib, "Msimg32.lib");
// Global Variables:

HINSTANCE hInst;                                // current instance
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];
WCHAR szChildWindowClass[MAX_LOADSTRING];
WCHAR szScoreWindowClass[MAX_LOADSTRING];
WCHAR szWINWindowClass[MAX_LOADSTRING];
HWND hWnd, hWnd1, hWnd2,hWndScore1,hWndScore2,winhand1,winhand2;
HWND hWndChild1[4][4];
HWND hWndChild2[4][4];
int score=0;
int state[4][4];
int gameend = 0;
int gamegoal = 2048;
int animacje[4][4];

// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
ATOM                MyRegisterChildClass(HINSTANCE hInstance);
ATOM                MyRegisterScoreClass(HINSTANCE hInstance);

ATOM                MyRegisterWINClass(HINSTANCE hInstance);

BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    WndProcChild(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProcScore(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProcWIN(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
HBRUSH PlateColour(int value, HDC hdc);
void GameRestart();
void UpdateW();
void UpdateS();
void UpdateA();
void UpdateD();
void Rollnew();
void Checkbox(int ile);
bool IsLost();
bool IsWon();
void EndScreen(int r, int g, int b);


int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Place code here.
    score = 0;
    // Initialize global strings
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_WINAPILAB1, szWindowClass, MAX_LOADSTRING);
    LoadStringW(hInstance, IDS_CHILDCLASS, szChildWindowClass, MAX_LOADSTRING);
    LoadStringW(hInstance, IDS_SCORECLASS, szScoreWindowClass, MAX_LOADSTRING);
    LoadStringW(hInstance, IDS_WINCLASS, szWINWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);
    MyRegisterChildClass(hInstance);
    MyRegisterScoreClass(hInstance);
    MyRegisterWINClass(hInstance);
    
    // Perform application initialization:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WINAPILAB1));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = CreateSolidBrush(RGB(250, 247, 238));
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_WINAPILAB1);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));

    return RegisterClassExW(&wcex);
}

ATOM MyRegisterChildClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProcChild;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = NULL;
    wcex.hCursor = LoadCursor(hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));
    wcex.hbrBackground = CreateSolidBrush(RGB(250, 247, 238));
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = szChildWindowClass;
    wcex.hIconSm = NULL;

    return RegisterClassExW(&wcex);
}

ATOM MyRegisterScoreClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProcScore;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = NULL;
    wcex.hCursor = LoadCursor(hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));
    wcex.hbrBackground = CreateSolidBrush(RGB(250, 247, 238));
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = szScoreWindowClass;
    wcex.hIconSm = NULL;

    return RegisterClassExW(&wcex);
}

ATOM MyRegisterWINClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProcWIN;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = CreateSolidBrush(RGB(0, 247,0));
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_WINAPILAB1);
    wcex.lpszClassName = szWINWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_WINAPILAB1));

    return RegisterClassExW(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // Store instance handle in our global variable
    ; /*= CreateWindowW(szWindowClass, szTitle,  | WS_VISIBLE,
           CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);
       hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW | WS_VISIBLE,
           150, 150, 150, 150, nullptr, nullptr, hInstance, nullptr);*/
    hWnd1 = hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW | WS_VISIBLE, 150, 150, 150, 150, NULL, NULL, hInstance, NULL);
    RECT rc;
    GetWindowRect(hWnd1, &rc);
    int x = GetSystemMetrics(SM_CXSCREEN) * 2 / 3;
    int y = GetSystemMetrics(SM_CYSCREEN) * 2 / 3;

    if (!hWnd)
    {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    hWndScore1 = CreateWindowW(szScoreWindowClass, nullptr, WS_CHILDWINDOW | WS_VISIBLE, 5, 5, 255, 60, hWnd1, nullptr, hInstance, nullptr);
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            hWndChild1[i][j] = CreateWindowW(szChildWindowClass, nullptr, WS_CHILD | WS_VISIBLE , 5 + j * 65, 70 + i * 65, 60, 60, hWnd, nullptr, hInstance, nullptr);
            SetWindowLong(hWndChild1[i][j], GWL_ID, 100 + i * 10 + j);
        }
    }

    hWnd2 = CreateWindow(szWindowClass, szTitle, WS_VISIBLE , x - rc.left, y - rc.top, rc.right - rc.left, rc.top - rc.bottom,hWnd, NULL, hInstance, NULL);

    hWndScore1 = CreateWindowW(szScoreWindowClass, nullptr, WS_CHILD | WS_VISIBLE , 5, 5, 255, 60, hWnd2, nullptr, hInstance, nullptr);

    if (!hWnd2)
    {
        return FALSE;
    }

    ShowWindow(hWnd2, nCmdShow);
    UpdateWindow(hWnd2);

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            hWndChild2[i][j] = CreateWindowW(szChildWindowClass, nullptr, WS_CHILD | WS_VISIBLE, 5 + j * 65, 70 + i * 65, 60, 60, hWnd2, nullptr, hInstance, nullptr);
            SetWindowLong(hWndChild2[i][j], GWL_ID, 200 + i * 10 + j);
        }
    }
    //MoveWindow(hWnd, 150, 150,150,150 ,FALSE);
    {
    ifstream save("save.txt");
    if (save.good()) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                save >> state[i][j];
            }
        }
        save >> score;
        save >> gamegoal;
        save >> gameend;
        Checkbox(gamegoal);
        save.close();
        if (gameend != 0) {
            if (gameend == 3 || gameend == 1) {
                SetTimer(hWnd1, 1337, 25, NULL);
                gameend = 1;
            }
            if (gameend == 4|| gameend == 2) {
                SetTimer(hWnd1, 90, 25, NULL);
                gameend = 2;
            }
        }
    }
    else
    {
        GameRestart();
    }
    save.close();
    InvalidateRect(hWnd1, NULL, TRUE);
    InvalidateRect(hWnd2, NULL, TRUE);
    }

   //GameRestart();
   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE: Processes messages for the main window.
//
//  WM_COMMAND  - process the application menu
//  WM_PAINT    - Paint the main window
//  WM_DESTROY  - post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HDC offDC = NULL;
    static HBITMAP offOldBitmap = NULL;
    static HBITMAP offBitmap = NULL;
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case ID_FILE_NEWGAME: 
        {
            GameRestart();
            InvalidateRect(hWnd1, NULL, TRUE);
            InvalidateRect(hWnd2, NULL, TRUE);
        }
        break;
        case IDM_ABOUT: {
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
        }
                      break;

        case ID_GOAL_8:
        {
            Checkbox(8);
        }
        break;
        case ID_GOAL_16:
        {
            Checkbox(16);
        }
        break;
        case ID_GOAL_64:
        {
            Checkbox(64);
        }
        break;
        case ID_GOAL_2048:
        {
            Checkbox(2048);
        }
        break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_GETMINMAXINFO:
    {
        MINMAXINFO* minMaxInfo = (MINMAXINFO*)lParam;
        minMaxInfo->ptMaxSize.x = minMaxInfo->ptMaxTrackSize.x = 281;
        minMaxInfo->ptMaxSize.y = minMaxInfo->ptMaxTrackSize.y = 324 + 65;
        minMaxInfo->ptMinTrackSize.x = 281;
        minMaxInfo->ptMinTrackSize.y = 324 + 65;
    }
    break;

    case WM_CREATE: {
        if (IsWon())SetTimer(hWnd1, 1337, 250, NULL);
            HDC hdc = GetDC(hWnd);
            offDC = CreateCompatibleDC(hdc);
            ReleaseDC(hWnd, hdc);
    }
    break;

    case WM_TIMER:
    {
        if (wParam == 1337) {
            KillTimer(hWnd, 1337);
            EndScreen(0, 70, 0);
        }
        if (wParam == 90) {
            KillTimer(hWnd, 90);
            EndScreen(70, 0, 0);
        }
    }
    break;


    case WM_KEYDOWN:
    {

        if (gameend == 0) {
            if (wParam == 0x57) {
                UpdateW();
                InvalidateRect(hWnd1, NULL, TRUE);
                InvalidateRect(hWnd2, NULL, TRUE);
                if (IsWon())SetTimer(hWnd1, 1337, 25, NULL);
            }
            if (wParam == 0x53) {
                UpdateS();
                InvalidateRect(hWnd1, NULL, TRUE);
                InvalidateRect(hWnd2, NULL, TRUE);
                if (IsWon())SetTimer(hWnd1, 1337, 25, NULL);
            }
            if (wParam == 0x41) {
                UpdateA();
                InvalidateRect(hWnd1, NULL, TRUE);
                InvalidateRect(hWnd2, NULL, TRUE);
                if (IsWon())SetTimer(hWnd1, 1337, 25, NULL);
            }
            if (wParam == 0x44) {
                UpdateD();
                InvalidateRect(hWnd1, NULL, TRUE);
                InvalidateRect(hWnd2, NULL, TRUE);
                if (IsWon())SetTimer(hWnd1, 1337, 25, NULL);
            }
            else {
                RedrawWindow(hWndScore1, 0, 0, 0);
                //score++;
                InvalidateRect(hWnd1, NULL, TRUE);
                InvalidateRect(hWnd2, NULL, TRUE);
                if (IsWon())SetTimer(hWnd1, 1337, 25, NULL);
            }
            if(IsLost())EndScreen(70, 0, 0);
        }
        else
        {
            if (gameend == 1) {
                EndScreen(0, 70, 0);
                gameend = 3;
            }
            if (gameend == 2) {
                EndScreen(70, 0, 0);
                gameend = 4;
            }
            }
        if (IsWon())SetTimer(hWnd1, 1337, 250, NULL);
    }
    break;

    case WM_MOVE: {
        RECT rc1;
        GetWindowRect(hWnd, &rc1);
        RECT rc2;
        GetWindowRect(hWnd2, &rc2);
        int x = GetSystemMetrics(SM_CXSCREEN) * 2 / 3;
        int y = GetSystemMetrics(SM_CYSCREEN) * 2 / 3;


        if (hWnd == hWnd2) {
            MoveWindow(hWnd1, x - rc1.left, y - rc1.top, rc1.right - rc1.left, rc1.top - rc1.bottom, TRUE);
        }
        if (hWnd == hWnd1) {
            MoveWindow(hWnd2, x - rc1.left, y - rc1.top, rc1.right - rc1.left, rc1.top - rc1.bottom, TRUE);
        }
        if (hWnd == hWnd1) {
            if (abs(rc1.right - rc2.right) < 220 && abs(rc1.top - rc2.top) < 220) {
                SetWindowLong(hWnd2, GWL_EXSTYLE, GetWindowLong(hWnd1, GWL_EXSTYLE) | WS_EX_LAYERED);
                SetLayeredWindowAttributes(hWnd2, 0, 255 * 50 / 100, LWA_ALPHA);
                UpdateWindow(hWnd2);
            }
            else
            {
                SetWindowLong(hWnd1, GWL_EXSTYLE, GetWindowLong(hWnd1, GWL_EXSTYLE) | WS_EX_LAYERED);
                SetLayeredWindowAttributes(hWnd2, 0, 255, LWA_ALPHA);
                UpdateWindow(hWnd2);
            }
        }

        int clientWidth = LOWORD(lParam);
         int clientHeight = HIWORD(lParam);
         HDC hdc = GetDC(hWnd);
         if (offOldBitmap != NULL) {
             SelectObject(offDC, offOldBitmap);
            
        }
         if (offBitmap != NULL) {
             DeleteObject(offBitmap);
            
        }
         offBitmap = CreateCompatibleBitmap(hdc, clientWidth, clientHeight);
         offOldBitmap = (HBITMAP)SelectObject(offDC, offBitmap);
         ReleaseDC(hWnd, hdc);


        break;
    }
    case WM_PAINT:
    {
        if (gameend != 1) {
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    InvalidateRect(hWndChild1[i][j], NULL, TRUE);
                    InvalidateRect(hWndChild2[i][j], NULL, TRUE);
                }
            }
        }
        PAINTSTRUCT ps;
        HDC hdc;
        /*if (gameend == 0) {*/
            hdc = BeginPaint(hWnd, &ps);
        //}
        //else {
        //    hdc = GetDCEx(hWnd1, 0, DCX_CACHE);
        //}
        
        // TODO: Add any drawing code that uses hdc here...
        if (gameend == 1) {
           // SendMessage(                hWndScore1,                WM_SETREDRAW,                FALSE,                0            );

            TCHAR s[] = _T(" Hello world ! ");
            HBITMAP bitmap = LoadBitmap(hInst,
                MAKEINTRESOURCE(IDB_BITMAP1));
            HDC memDC = CreateCompatibleDC(hdc);
            HBITMAP memBM = CreateCompatibleBitmap(memDC, 400, 400);
            SelectObject(memDC, memBM);
            //HDC memDC = GetDCEx(hWnd1, 0, DCX_CACHE);

            HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, bitmap);
            BLENDFUNCTION ble;


            ble.BlendFlags = 0;
            ble.BlendOp = AC_SRC_OVER;
            ble.AlphaFormat = 0;
            ble.SourceConstantAlpha = 100;
            AlphaBlend(hdc, 0, 0, 400, 400, memDC, 0, 0, 400, 400, ble);


           // StretchBlt(hdc, 0, 0, -200, 100, memDC, 0, 0, 48, 48, SRCCOPY);
            SetBkMode(hdc, TRANSPARENT);
            SelectObject(memDC, oldBitmap);
            DeleteObject(bitmap);
            DeleteDC(memDC);
        }
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY: {
        ofstream save("save.txt");
        save.clear();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                save << state[i][j] << " ";
            }
        }
        save << score << " " << gamegoal<<" "<<gameend;
        save.close();

        if (offOldBitmap != NULL) {
            SelectObject(offDC, offOldBitmap);
            
        }
         if (offDC != NULL) {
             DeleteDC(offDC);
            
        }
         if (offBitmap != NULL) {
             DeleteObject(offBitmap);
            
        }

        PostQuitMessage(0);
    }
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK WndProcChild(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_GETMINMAXINFO:
    {
        MINMAXINFO* minMaxInfo = (MINMAXINFO*)lParam;
        minMaxInfo->ptMaxSize.x = minMaxInfo->ptMaxTrackSize.x = 281;
        minMaxInfo->ptMaxSize.y = minMaxInfo->ptMaxTrackSize.y = 324;
        minMaxInfo->ptMinTrackSize.x = 281;
        minMaxInfo->ptMinTrackSize.y = 324;
    }
    break;

    case WM_TIMER:
    {
        if(gameend==0 && ANIMATING> 1){
            {
                if (ANIMATING == 1) {
                    if (wParam == 101) {
                        KillTimer(hWnd, 101);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 30;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 102, ANISPEED, NULL);
                    }

                    if (wParam == 102) {
                        KillTimer(hWnd, 102);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 25;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 103, ANISPEED, NULL);
                    }

                    if (wParam == 103) {
                        KillTimer(hWnd, 103);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 20;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 104, ANISPEED, NULL);
                    }
                    if (wParam == 104) {
                        KillTimer(hWnd, 104);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 15;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 105, ANISPEED, NULL);
                    }
                    if (wParam == 105) {
                        KillTimer(hWnd, 105);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 10;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 106, ANISPEED, NULL);
                    }if (wParam == 106) {
                        KillTimer(hWnd, 106);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 5;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 107, ANISPEED, NULL);
                    }
                    if (wParam == 107) {
                        KillTimer(hWnd, 107);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 0;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        //SetTimer(hWnd, 105, ANISPEED, NULL);
                    }
                }
                if (ANIMATING == 2) {
                
                    if (wParam == 101) {
                        KillTimer(hWnd, 101);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 30;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 102, ANISPEED, NULL);
                    }

                    if (wParam == 102) {
                        KillTimer(hWnd, 102);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 15;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        SetTimer(hWnd, 103, ANISPEED, NULL);
                    }

                    if (wParam == 103) {
                        KillTimer(hWnd, 103);
                        //printf("%d ", 4);
                        int x = GetWindowLong(hWnd, GWL_ID);
                        int y = (x % 100) / 10;
                        x = x % 10;
                        int ofset = 0;
                        RECT rc;
                        GetWindowRect(hWnd, &rc);
                        MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                        //SetTimer(hWnd, 104, ANISPEED, NULL);
                    }
                }
            }
            {
                if (wParam == 201)
                {
                    KillTimer(hWnd, 201);
                    //printf("%d ", 4);
                    int x = GetWindowLong(hWnd, GWL_ID);
                    int y = (x % 100) / 10;
                    x = x % 10;
                    int ofset = -5;
                    RECT rc;
                    GetWindowRect(hWnd, &rc);
                    MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                    SetTimer(hWnd, 202, 2 * ANISPEED, NULL);
                }
                if (wParam == 202)
                {
                    KillTimer(hWnd, 202);
                    //printf("%d ", 4);
                    int x = GetWindowLong(hWnd, GWL_ID);
                    int y = (x % 100) / 10;
                    x = x % 10;
                    int ofset = -10;
                    RECT rc;
                    GetWindowRect(hWnd, &rc);
                    MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                    SetTimer(hWnd, 203, 2 * ANISPEED, NULL);
                }
                if (wParam == 203)
                {
                    KillTimer(hWnd, 203);
                    //printf("%d ", 4);
                    int x = GetWindowLong(hWnd, GWL_ID);
                    int y = (x % 100) / 10;
                    x = x % 10;
                    int ofset = -5;
                    RECT rc;
                    GetWindowRect(hWnd, &rc);
                    MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                    SetTimer(hWnd, 204, 2 * ANISPEED, NULL);
                }
                if (wParam == 204)
                {
                    KillTimer(hWnd, 204);
                    //printf("%d ", 4);
                    int x = GetWindowLong(hWnd, GWL_ID);
                    int y = (x % 100) / 10;
                    x = x % 10;
                    int ofset = 0;
                    RECT rc;
                    GetWindowRect(hWnd, &rc);
                    MoveWindow(hWnd, 5 + x * 65 + ofset, 70 + y * 65 + ofset, 60 - 2 * ofset, 60 - 2 * ofset, TRUE);
                }
            }

        }

        else
        {
            KillTimer(hWnd, lParam);
        }
    }

    case WM_MOVE: {


        break;
    }
    case WM_PAINT:
    {
        if (true) {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);

            int x = GetWindowLong(hWnd, GWL_ID);
            int y = (x % 100) / 10;
            x = x % 10;
            RECT rec;
            GetClientRect(hWnd, &rec);
            HBRUSH brush = PlateColour(state[x][y], hdc);
            HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, brush);
            HPEN pen = CreatePen(PS_NULL, 1, RGB(0, 0, 0));
            HPEN oldPen = (HPEN)SelectObject(hdc, pen);
            RoundRect(hdc, 0, 0, rec.right - rec.left, rec.bottom - rec.top, 15, 15);
            HFONT font = CreateFont(
                30, // Height
                0, // Width
                0, // Escapement
                0, // Orientation
                FW_BOLD, // Weight
                FALSE, // Italic
                FALSE, // Underline

                0, // StrikeOut
                EASTEUROPE_CHARSET, // CharSet
                OUT_DEFAULT_PRECIS, // OutPrecision
                CLIP_DEFAULT_PRECIS, // ClipPrecision
                CLEARTYPE_QUALITY, // Quality
                DEFAULT_PITCH | FF_SWISS, // PitchAndFamily
                _T(" Verdana ")); // Facename
            HFONT oldFont = (HFONT)SelectObject(hdc, font);
            RoundRect(hdc, 0, 0, rec.right - rec.left, rec.bottom - rec.top, 15, 15);
            RECT rc;
            GetClientRect(hWnd, &rc);
            SetBkMode(hdc, TRANSPARENT);

            wchar_t buf[21];
            wsprintfW(buf, L"%d", state[x][y]);
            DrawText(hdc, buf, log10(state[x][y]) + 1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            SelectObject(hdc, oldFont);
            DeleteObject(font);
            SelectObject(hdc, oldPen);
            DeleteObject(pen);
            SelectObject(hdc, oldBrush);
            DeleteObject(brush);
            EndPaint(hWnd, &ps);
            // TODO: Add any drawing code that uses hdc here...
            if (gameend == 1) {
                //PAINTSTRUCT ps;
                //HDC hdc = BeginPaint(hWnd, &ps);
                //TCHAR s[] = _T(" Hello world ! ");
                //HBITMAP bitmap = LoadBitmap(hInst,
                //    MAKEINTRESOURCE(IDB_BITMAP1));
                //HDC memDC = CreateCompatibleDC(hdc);
                //HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, bitmap);
                //BLENDFUNCTION ble;


                //ble.BlendFlags = 0;
                //ble.BlendOp = AC_SRC_OVER;
                //ble.AlphaFormat = 0;
                //ble.SourceConstantAlpha = 70;
                //AlphaBlend(hdc, 0, 0, 400, 400, memDC, 0, 0, 400, 400, ble);


                ////StretchBlt(hdc, 0, 0, -200, 100, memDC, 0, 0, 48, 48, SRCCOPY);
                //SelectObject(memDC, oldBitmap);
                //DeleteObject(bitmap);
                //DeleteDC(memDC);
                //EndPaint(hWnd, &ps);
            }




        }
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
LRESULT CALLBACK WndProcScore(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {

    
    }
    break;
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_GETMINMAXINFO:
    {
        MINMAXINFO* minMaxInfo = (MINMAXINFO*)lParam;
        minMaxInfo->ptMaxSize.x = minMaxInfo->ptMaxTrackSize.x = 281;
        minMaxInfo->ptMaxSize.y = minMaxInfo->ptMaxTrackSize.y = 324;
        minMaxInfo->ptMinTrackSize.x = 281;
        minMaxInfo->ptMinTrackSize.y = 324;
    }
    break;

    case WM_MOVE: {

        break;
    }
    case WM_PAINT:
    {
        if (true) {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: Add any drawing code that uses hdc here...

            HBRUSH brush = CreateSolidBrush(RGB(204, 192, 174));
            HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, brush);
            HPEN pen = CreatePen(PS_NULL, 1, RGB(0, 0, 0));
            HPEN oldPen = (HPEN)SelectObject(hdc, pen);

            HFONT font = CreateFont(
                30, // Height
                0, // Width
                0, // Escapement
                0, // Orientation
                FW_BOLD, // Weight
                FALSE, // Italic
                FALSE, // Underline

                0, // StrikeOut
                EASTEUROPE_CHARSET, // CharSet
                OUT_DEFAULT_PRECIS, // OutPrecision
                CLIP_DEFAULT_PRECIS, // ClipPrecision
                CLEARTYPE_QUALITY, // Quality
                DEFAULT_PITCH | FF_SWISS, // PitchAndFamily
                _T(" Verdana ")); // Facename
            HFONT oldFont = (HFONT)SelectObject(hdc, font);

            RoundRect(hdc, 0, 0, 255, 60, 15, 15);
            RECT rc;
            GetClientRect(hWnd, &rc);
            SetBkMode(hdc, TRANSPARENT);

            wchar_t buf[21];
            wsprintfW(buf, L"%d", score);
            DrawText(hdc, buf, log10(score + 1) + 1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            SelectObject(hdc, oldFont);
            DeleteObject(font);
            SelectObject(hdc, oldPen);
            DeleteObject(pen);
            SelectObject(hdc, oldBrush);
            DeleteObject(brush);


            EndPaint(hWnd, &ps);
        }
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK WndProcWIN(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        case ID_FILE_NEWGAME:
        {
        }
        break;
        case IDM_ABOUT: {
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
        }
                      break;

     
        case IDM_EXIT:
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_GETMINMAXINFO:
    {
        MINMAXINFO* minMaxInfo = (MINMAXINFO*)lParam;
        minMaxInfo->ptMaxSize.x = minMaxInfo->ptMaxTrackSize.x = 281;
        minMaxInfo->ptMaxSize.y = minMaxInfo->ptMaxTrackSize.y = 324 + 65;
        minMaxInfo->ptMinTrackSize.x = 281;
        minMaxInfo->ptMinTrackSize.y = 324 + 65;
    }
    break;
    case WM_KEYDOWN:
    break;
    case WM_CREATE: {
        SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
        SetLayeredWindowAttributes(hWnd, 0, 255 / 2, LWA_ALPHA);
        UpdateWindow(hWnd);
    }
                  break;
    case WM_MOVE: {

    }
                break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        if (gameend != 0) {
            //TCHAR s[] = _T(" Hello world ! ");
            //HBITMAP bitmap = LoadBitmap(hInst,
            //    MAKEINTRESOURCE(IDB_BITMAP1));
            //HDC memDC = CreateCompatibleDC(hdc);
            //HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, bitmap);
            //BLENDFUNCTION ble;
            //ble.BlendFlags = 0;
            //ble.BlendOp = AC_SRC_OVER;
            //ble.AlphaFormat = AC_SRC_ALPHA;
            //ble.SourceConstantAlpha = 120;
            ////AlphaBlend(hdc, 0, 0, 160, 160, memDC, 0, 0, 160,160,ble);
            // //StretchBlt(hdc, 0, 0, -200, 100, memDC,
            //  //  0, 0, 48, 48, SRCCOPY);
            //SelectObject(memDC, oldBitmap);
            //DeleteObject(bitmap);
            //DeleteDC(memDC);
        }
        //
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY: {
        PostQuitMessage(0);
    }
                   break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}



// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}


HBRUSH PlateColour(int value,HDC hdc) {
    switch (value)
    {
    case 0:
        return CreateSolidBrush(RGB(204, 192, 174));
        break;
    case 2:
        return CreateSolidBrush(RGB(238, 228, 198));
        break;
    case 4:
        return CreateSolidBrush(RGB(239, 225, 218));
        break;
    case 8:
        return CreateSolidBrush(RGB(243, 179, 124));
        break;
    case 16:
        return CreateSolidBrush(RGB(246, 153, 100));
        break;
    case 32:
        return CreateSolidBrush(RGB(246, 125, 98));
        break;
    case 64:
        return CreateSolidBrush(RGB(247, 93, 60));
        break;
    case 128:
        return CreateSolidBrush(RGB(237, 206, 116));
        break;
    case 256:
        return CreateSolidBrush(RGB(239, 204, 98));
        break;
    case  512:
        return CreateSolidBrush(RGB(243, 201, 85));
        break;
    case  1024:
        return CreateSolidBrush(RGB(238, 200, 72));
        break;
    case  2048:
        return CreateSolidBrush(RGB(239, 192, 47));
        break;
    default:
        return CreateSolidBrush(RGB(0, 192, 0));
        break;
    }
}

void GameRestart() {
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            state[i][j] = 0;
        }
    }
    score = 0;
    gameend = 0;
    Rollnew();
}

void UpdateW() {
    int flag = 0, i = 0, j = 0;
    for (int x = 0; x < 4; x++) {
        for (int i = 0; i < 4; i++) {
            for (int j = i + 1; j < 4; j++) {
                if (state[x][j] != 0) {
                    if (state[x][i] == 0) {
                        state[x][i] = state[x][j];
                        state[x][j] = 0;
                        flag = 1;
                    }
                    else if (state[x][i] == state[x][j]) {
                        state[x][i] = 2 * state[x][j];
                        SetTimer(hWndChild1[i][x], 201, 25, NULL);
                        SetTimer(hWndChild2[i][x], 201, 25, NULL);
                        animacje[x][i] = 1;
                        score += state[x][i];
                        state[x][j] = 0;
                        if (state[x][i] == gamegoal) {
                            gameend = 1;
                            SetTimer(hWnd1, 1337, 25, NULL);
                        }
                        flag = 1;
                        break;
                    }
                    else break;
                }
            }
        }
    }

    if (flag == 1) {
        Rollnew();
    }
}
void UpdateS() {
    int flag = 0, i = 0, j = 0;
    for (int x = 0; x < 4; x++) {
        for (int i = 3; i >= 0; i--) {
            for (int j = i - 1; j >= 0; j--) {
                if (state[x][j] != 0) {
                    if (state[x][i] == 0) {
                        state[x][i] = state[x][j];
                        state[x][j] = 0;
                        flag = 1;
                    }
                    else if (state[x][i] == state[x][j]) {
                        state[x][i] = 2 * state[x][j];
                        SetTimer(hWndChild1[i][x], 201, 25, NULL);
                        SetTimer(hWndChild2[i][x], 201, 25, NULL);
                        animacje[x][i] = 1;
                        score += state[x][i];
                        state[x][j] = 0;
                        if (state[x][i] == gamegoal) {
                            gameend = 1;
                            SetTimer(hWnd1, 1337, 25, NULL);
                        }
                        flag = 1;
                        break;
                    }
                    else break;
                }
            }
        }
    }

    if (flag == 1)
        Rollnew();
}

void UpdateA() {
    int flag = 0, i = 0, j = 0;
    for (int x = 0; x < 4; x++) {
        for (int i = 0; i < 4; i++) {
            for (int j = i + 1; j < 4; j++) {
                if (state[j][x] != 0) {
                    if (state[i][x] == 0) {
                        state[i][x] = state[j][x];
                        animacje[i][x] = 1;
                        state[j][x] = 0;
                        flag = 1;
                    }
                    else if (state[i][x] == state[j][x]) {
                        state[i][x] = 2 * state[j][x];
                        SetTimer(hWndChild1[x][i], 201, 25, NULL);
                        SetTimer(hWndChild2[x][i], 201, 25, NULL);
                        score += state[i][x];
                        state[j][x] = 0;
                        if (state[x][i] == gamegoal) {
                            gameend = 1;
                            SetTimer(hWnd1, 1337, 25, NULL);
                        }
                        flag = 1;
                        break;
                    }
                    else break;
                }
            }
        }
    }

    if (flag == 1) {
        Rollnew();
    }
}
void UpdateD() {
    int flag = 0, i = 0, j = 0;
    for (int x = 0; x < 4; x++) {
        for (int i = 3; i >= 0; i--) {
            for (int j = i - 1; j >= 0; j--) {
                if (state[j][x] != 0) {
                    if (state[i][x] == 0) {
                        state[i][x] = state[j][x];
                        state[j][x] = 0;
                        flag = 1;
                    }
                    else if (state[i][x] == state[j][x]) {
                        state[i][x] = 2 * state[j][x];
                        SetTimer(hWndChild1[x][i], 201, 25, NULL);
                        SetTimer(hWndChild2[x][i], 201, 25, NULL);
                        animacje[i][x] = 1;
                        score +=state[i][x];
                        state[j][x] = 0;
                        if (state[x][i] == gamegoal) {
                            gameend = 1;
                            SetTimer(hWnd1, 1337, 25, NULL);
                        }
                        flag = 1;
                        break;
                    }
                    else break;
                }
            }
        }
    }

    if (flag == 1)
        Rollnew();
}

void Rollnew()
{
    int x, y,z;
    do {
        x = rand() % 4;
        y = rand() % 4;
        z = rand() % 2+1;
    } while (state[x][y]!=0);
    animacje[x][y] = 2;
    state[x][y] = z * 2;
    SetTimer(hWndChild1[y][x], 101, 25, NULL);
    SetTimer(hWndChild2[y][x], 101, 25, NULL);
}   

bool IsLost()
{
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (state[i][j] == 0) return false;
            if (i - 1 >= 0 && state[i - 1][j] == state[i][j])return false;
            if (j - 1 >= 0 && state[i][j - 1] == state[i][j])return false;
            if (j + 1 < 4 && state[i][j + 1] == state[i][j])return false;
            if (i + 1 < 0 && state[i + 1][j] == state[i][j])return false;
        }
    }
    gameend = 2;
    EndScreen(70, 0, 0);
    return true;
}

bool IsWon()
{
    //score=gamegoal;
    if (gameend == 0) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (state[i][j] == gamegoal) {
                    gameend = 1;
                    EndScreen(0, 70, 0);
                    return true;
                }
            }
        }
    }
    return false;
}

void Checkbox(int ile)
{
    switch (ile) 
    {
    case 8:
    {
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_8, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_2048, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_8, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_2048, MF_UNCHECKED);
        gamegoal = 8;
    }
    break;
    case 16:
    {
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_16, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_2048, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_16, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_2048, MF_UNCHECKED);
        gamegoal = 16;
    }
    break;
    case 64:
    {
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_64, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_2048, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_64, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_2048, MF_UNCHECKED);
        gamegoal = 64;
    }
    break;
    case 2048:
    {
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd1), ID_GOAL_2048, MF_CHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_8, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_16, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_64, MF_UNCHECKED);
        CheckMenuItem(GetMenu(hWnd2), ID_GOAL_2048, MF_CHECKED);
        gamegoal = 2048;
    }
    break;
    }
}

void EndScreen(int r, int g, int b) {
    RECT window1, window2;
    GetClientRect(hWnd1, &window1);
    GetClientRect(hWnd2, &window2);


    auto hdcW1 = GetDC(hWnd1);
    auto hdcW2 = GetDC(hWnd2);
    auto Bitmapa1 = CreateCompatibleDC(hdcW1);
    auto Bitmapa2 = CreateCompatibleDC(hdcW2);

    auto ComMap1 = CreateCompatibleBitmap(hdcW1, window1.right - window1.left, window1.bottom - window1.top);
    auto ComMap2 = CreateCompatibleBitmap(hdcW2, window2.right - window2.left, window2.bottom - window2.top);

    auto oldBit1 = (HBITMAP)SelectObject(Bitmapa1, ComMap1);
    auto oldBit2 = (HBITMAP)SelectObject(Bitmapa2, ComMap2);

    auto brush = CreateSolidBrush(RGB(r, g, b));

    FillRect(Bitmapa1, &window1, brush);
    FillRect(Bitmapa2, &window2, brush);

    DeleteObject(brush);

    BLENDFUNCTION ble;

    ble.BlendFlags = 0;
    ble.BlendOp = AC_SRC_OVER;
    ble.AlphaFormat = 0;
    ble.SourceConstantAlpha = 100;

    AlphaBlend(hdcW1, window1.left, window1.top, window1.right - window1.left, window1.bottom - window1.top, Bitmapa1, window1.left, window1.top, window1.right - window1.left, window1.bottom - window1.top, ble);
    AlphaBlend(hdcW2, window2.left, window2.top, window2.right - window2.left, window2.bottom - window2.top, Bitmapa2, window2.left, window2.top, window2.right - window2.left, window2.bottom - window2.top, ble);
    if (gameend == 1 || gameend == 3) {
        SetTextColor(hdcW1, RGB(255, 255, 255));
        SetTextColor(hdcW2, RGB(255, 255, 255));
        //wchar_t buf[21];
        SetBkMode(hdcW1, TRANSPARENT);
        SetBkMode(hdcW2, TRANSPARENT);
        DrawText(hdcW1, L"WIN!", -1, &window1, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        DrawText(hdcW2, L"WIN!", -1, &window2, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
    if (gameend == 2 || gameend == 4) {
        SetTextColor(hdcW1, RGB(255, 255, 255));
        SetTextColor(hdcW2, RGB(255, 255, 255));
        //wchar_t buf[21];
        SetBkMode(hdcW1, TRANSPARENT);
        SetBkMode(hdcW2, TRANSPARENT);
        DrawText(hdcW1, L"LOSS!", -1, &window1, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        DrawText(hdcW2, L"LOOS!", -1, &window2, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
    DeleteObject(oldBit1);
    DeleteObject(oldBit2);
    DeleteObject(oldBit1);
    DeleteObject(ComMap1);
    DeleteObject(ComMap2);
    ReleaseDC(hWnd1, hdcW1);
    ReleaseDC(hWnd2, hdcW2);
    //ReleaseDC(hWnd1, Bitmapa1);
    //ReleaseDC(hWnd2, Bitmapa2);
    DeleteDC(hdcW1);
    DeleteDC(hdcW2);
    DeleteObject(Bitmapa1);
    DeleteObject(Bitmapa2);

}